<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Hybrid Mobile App Development';
$bannerText    = 'Streamline Development with Hybrid Mobile Apps for Fast, Scalable Solutions Across Multiple Platforms.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'hybrid-mobile-app-development',
    'title'        => 'Efficient Hybrid <span>Mobile Apps for Business Growth</span>',
    'introParas'   => [
        'Hybrid mobile app development combines the best of native and web technologies, allowing apps to be built using web technologies like HTML5, CSS, and JavaScript but wrapped in a native app shell.',
        'This approach enables access to device hardware (e.g., camera, GPS) while maintaining the flexibility of web-based technologies. Using frameworks like Ionic and Apache Cordova, hybrid apps can provide a near-native experience while reducing development costs and time. Hybrid apps are ideal for companies looking to launch quickly across multiple platforms with moderate performance requirements.'
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>