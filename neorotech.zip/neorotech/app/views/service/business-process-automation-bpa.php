<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Business Process Automation (BPA)';
$bannerText    = 'Automate repetitive tasks to improve efficiency, reduce human error, and save time with BPA solutions.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'website-maintenance',
    'title'        => 'Optimize Business Performance with<span>  Process Automation</span>',
    'introParas'   => [
        'Websites require regular updates and monitoring to remain secure, functional, and aligned with the latest technologies. Our <strong>website maintenance and support services</strong> are designed to keep your website running smoothly and securely, ensuring minimal downtime and maximum performance.',
        'We provide ongoing support that includes software updates, security patches, performance optimizations, and content updates. Additionally, we offer data backups and monitoring services to safeguard your website from potential threats and provide peace of mind.',
        'Our proactive approach helps prevent issues before they arise, so you can focus on your core business.'
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>