<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Mobile App Design';
$bannerText    = 'Designing intuitive, visually engaging mobile apps that provide seamless user experiences for improved engagement and retention.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'mobile-app-design',
    'title'        => 'Cutting-Edge <span>Mobile App Design Tailored</span>  for Every Platform',
    'introParas'   => [
        'We specialize in mobile app design, focusing on creating user-friendly, visually appealing interfaces that ensure seamless navigation and engagement.',
        'Our designs are optimized for performance across various mobile devices, making your app intuitive and enjoyable to use.',
        'We enhance user retention by delivering functional, aesthetically pleasing mobile experiences and Our Services'
    ]
];
?>

<!-- Mobile App Design Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>