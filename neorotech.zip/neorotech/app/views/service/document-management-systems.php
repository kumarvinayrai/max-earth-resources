<?php

declare(strict_types=1);

// Page Meta
$bannerImage   = '/assets/images/banner/banner-01.jpg';
$bannerHeading = 'Document Management Systems';
$bannerText    = 'mplement document management systems to securely store, track, and organize electronic documents for better access.';

// Includes
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
include __DIR__ . '/../includes/banner.php';

// Intro Data
$servicesData = [
    'sectionId'    => 'document-management-systems',
    'title'        => 'Centralized Document Management for<span>  Seamless Collaboration</span>',
    'introParas'   => [
        'Our Document Management Systems (DMS) provide businesses with a centralized platform to securely store, manage, and track digital documents. With cloud-based solutions, your team can easily access documents from anywhere while maintaining secure access controls. DMS streamlines document workflows, enhances collaboration, and improves productivity.',
        'By reducing reliance on paper and automating document-related tasks, we help businesses ensure compliance, improve document retrieval times, and promote efficiency, ultimately leading to better decision-making and smoother operations.',
    ]
];
?>

<!-- Website Maintenance Section -->
<section id="<?= htmlspecialchars($servicesData['sectionId']) ?>" class="position-relative py-5" aria-labelledby="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading">
    <div class="container">
        <div class="row align-items-center g-5 lead lh-base">
            <div class="col-lg-5" data-aos="fade-right">
                <header>
                    <h2 id="<?= htmlspecialchars($servicesData['sectionId']) ?>-heading" class="heading-title my-3">
                        <?= $servicesData['title'] ?>
                    </h2>
                </header>
            </div>
            <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                <?php foreach ($servicesData['introParas'] as $para): ?>
                    <p class="text-muted"><?= $para ?></p>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/web-development-services.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>