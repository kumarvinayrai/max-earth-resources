<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Neorotech Software Solutions Pvt. Ltd. | Software Development Company in India</title>
  <meta name="description" content="Neorotech Software Solutions Pvt. Ltd. provides innovative software development, consulting, and digital transformation services for global clients." />
  <meta name="robots" content="index, follow" />
  <meta name="author" content="Neorotech Software Solutions Pvt. Ltd." />
  <!-- Favicon (optional) -->
  <link rel="icon" href="/assets/images/favicon.ico" type="image/x-icon" />
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-..." crossorigin="anonymous" />
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet" integrity="sha384-..." crossorigin="anonymous" />
  <!-- AOS CSS (if needed later) -->
  <!-- <link rel="stylesheet" href="/assets/css/aos.css"  /> -->
  <!-- Custom CSS -->
  <link rel="stylesheet" href="/assets/css/style.css" />
</head>
<script></script>
<body>
